package com.example.timeapp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Log.e("Hello","xin chào");

        String chuoi_string = intent.getExtras().getString("extra");
        Log.e("Bạn truyền key", chuoi_string);

        Intent intent1 = new Intent(context,Music.class);
        intent1.putExtra("extra",chuoi_string);
        context.startService(intent1);
    }
}
